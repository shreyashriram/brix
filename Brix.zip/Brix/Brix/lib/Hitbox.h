//
//  Hitbox.h
//  Brix
//
//  Created by Shreya Shriram on 12/7/21.
//
#include <iostream>
using namespace std;

#include <stdio.h>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#ifndef Hitbox_h
#define Hitbox_h

struct Hitbox {
    
    double cornerX, cornerY;
    double sizeX, sizeY;
    
    Hitbox(double posX = 0, double posY = 0, double width = 0.1, double height = 0.1) : cornerX(posX), cornerY(posY), sizeX(width), sizeY(height) {};
    
    // positions
    double getX() {
        return cornerX;
    }
    
    double getY() {
        return cornerY;
    }
    
    void setX(double x) {
        cornerX = x;
    }
    
    void setY(double y) {
        cornerY = y;
    }
    
    // size
    double getXsize() {
        return sizeX;
    }
    
    double getYsize() {
        return sizeY;
    }
    
    void setXsize(double x) {
        sizeX = x;
    }
    
    void setYsize(double y) {
        sizeY = y;
    }
    
    void draw() {
        //scaledGetCursorPos(cx, cy);
        glColor3f(1.0f, 0.0f, 1.0f);
        glBegin(GL_QUADS);
        glVertex2f(cornerX, cornerY);
        glVertex2f(cornerX + sizeX, cornerY);
        glVertex2f(cornerX + sizeX, cornerY -  sizeY);
        glVertex2f(cornerX, cornerY - sizeY);
        glEnd();
    }

};

#endif /* Hitbox_h */
