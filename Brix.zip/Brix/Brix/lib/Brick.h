//
//  Brick.h
//  Brix
//
//  Created by Shreya Shriram on 12/7/21.
//
#include <iostream>
using namespace std;

#include <stdio.h>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#ifndef Brick_h
#define Brick_h

#include "Hitbox.h"

class Brick {
public:
    Hitbox hbox;
    float r;
    float g;
    float b;
    
    bool state;
    
    Brick();
    Brick(double xpos, double ypos);
    
    void draw();
    
    bool getState();
    void changeState();
};


#endif /* Brick_h */
