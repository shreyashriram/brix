//
//  Ball.h
//  Brix
//
//  Created by Shreya Shriram on 12/7/21.
//
#include <iostream>
using namespace std;

#include <stdio.h>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
//
//#ifndef Ball_h
//#define Ball_h

#include "Hitbox.h"

class Ball {
public:
    Hitbox hbox;
    int Angle;
    int Velocity;
    int xmult;
    int ymult;
    int lives;
    
    Ball();
    
    void updatePos();
    void draw();
    
    bool collison_dectection(Hitbox);
    void collison_response();
    
    // Getters
    int getAngle();
    int getVelocity();
    int getXmult();
    int getYmult();
    
    // Setters
    void setAngle(int theta);
    void setVelocity(int v);
    void changeXmult();
    void changeYmult();
    
};
//
//#endif /* Ball_h */
