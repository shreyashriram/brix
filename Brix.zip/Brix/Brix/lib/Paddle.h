//
//  Paddle.h
//  Brix
//
//  Created by Shreya Shriram on 12/7/21.
//
#include <iostream>
using namespace std;

#include <stdio.h>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#ifndef Paddle_h
#define Paddle_h

#include "Hitbox.h"

class Paddle {
public:
    Hitbox hbox;
    
    Paddle();
    Paddle(double, double, double, double);
    
    void updatePos(double);
    void draw();
};


#endif /* Paddle_h */
