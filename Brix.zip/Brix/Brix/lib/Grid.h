//
//  Grid.h
//  Brix
//
//  Created by Shreya Shriram on 12/7/21.
//
#include <iostream>
using namespace std;

#include <stdio.h>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#ifndef Grid_h
#define Grid_h

#include "Brick.h"

class Grid {
public:
    Brick brickArr[5][10];
    int numBricks;
    int row;
    int col;
    
    Grid();
    
    void brickConfig();
    void draw();
};

#endif /* Grid_h */
