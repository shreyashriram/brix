//
//  Ball.cpp
//  Brix
//
//  Created by Shreya Shriram on 12/7/21.
//
#include <iostream>
using namespace std;

#include <stdio.h>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include "Hitbox.h"
#include "Ball.h"

#include <cmath>

#define PI 3.14159265

Ball::Ball() : hbox(0, 0, 0.02, 0.02), Angle(-125), Velocity(12), xmult(1), ymult(1), lives(3){};

void Ball::updatePos() {
    double delta_y = Velocity * sin((Angle * PI) / 180);
    double delta_x = Velocity * cos((Angle * PI) / 180);
    
    hbox.setX(hbox.getX() + ((xmult)*(delta_x/1000)));
    hbox.setY(hbox.getY() + ((ymult)*(delta_y/1000)));
}

void Ball::draw() {
    int triangleAmount = 20; //# of triangles used to draw circle
    double radius = 0.055;

    double x = hbox.getX();
    double y = hbox.getY();

    
    GLfloat twicePi = 2.0f * 3.14159265358979323846;
    glColor3f(1.0f, 0.0f, 0.125f);
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // center of circle
    
    for (int i = 0; i <= triangleAmount; i++) {
        glVertex2f(
            x + (radius * cos(i * twicePi / triangleAmount)),
                   y + (radius * sin(i * twicePi / triangleAmount))
        );
    }
     
    glEnd();
}

bool Ball::collison_dectection(Hitbox other) {
    bool collisionX = hbox.cornerX + hbox.sizeX >= other.cornerX &&
           other.cornerX + other.sizeX >= hbox.cornerX;

    bool collisionY = hbox.cornerY + hbox.sizeY >= other.cornerY &&
           other.cornerY + other.sizeY >= hbox.cornerY;
    return collisionX && collisionY;
}

void Ball::collison_response() {
    Velocity = 0;
}

// Getters
int Ball::getAngle() {
    return Angle;
}

int Ball::getVelocity() {
    return Velocity;
}

int Ball::getXmult() {
    return xmult;
}

int Ball::getYmult() {
    return ymult;
}


// Setters
void Ball::setAngle(int theta) {
    Angle = theta;
}

void Ball::setVelocity(int v) {
    Velocity = v;
}

void Ball::changeXmult() {
    xmult = -1*xmult;
}

void Ball::changeYmult() {
    ymult = -1*ymult;
}




