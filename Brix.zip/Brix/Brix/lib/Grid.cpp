//
//  Grid.cpp
//  Brix
//
//  Created by Shreya Shriram on 12/7/21.
//
#include <iostream>
using namespace std;

#include <stdio.h>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include "Hitbox.h"
#include "Brick.h"
#include "Grid.h"

Grid::Grid() : row(5), col(10), numBricks(50) {};

void Grid::brickConfig() {
    double brickWidth = brickArr[0][0].hbox.getXsize();
    double brickHeight = brickArr[0][0].hbox.getYsize();;
    
    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            brickArr[i][j].hbox.setX(-1 + (j*(brickWidth+0.05)));
            brickArr[i][j].hbox.setY(1 - (i*(brickHeight+0.025)));
            
            cout << brickArr[i][j].hbox.getX() << ", " << brickArr[i][j].hbox.getY() << endl;
        }
        
        cout << "................" << endl;
    }
}

void Grid::draw() {
    for (int i = 0; i < row; i++) {
        for (int j = 0; i < col; j++) {
            brickArr[i][j].draw();
        }
    }
}
