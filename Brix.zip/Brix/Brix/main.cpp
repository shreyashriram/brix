#include <iostream>
#include <cstdlib>
using namespace std;

// GLEW
#define GLEW_STATIC
#include <GL/glew.h>

// GLFW
#include <GLFW/glfw3.h>

// Game Objects
#include "Hitbox.h"
#include "Paddle.h"
#include "Ball.h"
#include "Brick.h"
#include "Grid.h"
#include <random>

const GLint WIDTH = 1000, HEIGHT = 1000;

void scaledGetCursorPos(GLFWwindow* window, double& cx, double& cy)
{
    glfwGetCursorPos(window, &cx, &cy);
    
    cout << cx << ", " << cy << endl;
    
    cx = (cx - (WIDTH / 2)) / (WIDTH / 2);
    cy = -(cy - (WIDTH / 2)) / (WIDTH / 2);
    
    return;
}

// Callback definitions
static void cursor_position_callback(GLFWwindow* window, double xpos, double ypos) {}
static void error_callback(int error, const char* description) { fprintf(stderr, "Error: %s\n", description); }

int main() {
    GLFWwindow* window;

    /* Initialize the library */
    if (!glfwInit())
        return -1;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(WIDTH, HEIGHT, "Brix", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    /* Make the window's context current */
    glfwMakeContextCurrent(window);

    if (glewInit() != GLEW_OK)
        std::cout << "GLEW was not ok" << std::endl;

    std::cout << glGetString(GL_VERSION) << std::endl;

    /* Set event callbacks */
    glfwSetErrorCallback(error_callback);
    glfwSetCursorPosCallback(window, cursor_position_callback);
    
    
    double cx, cy;
    
    // initalize main pieces
    Paddle player;
    Ball ball;
    Brick brickArr[5][10];
    
    // create brick grid, intstantiate locations
    double brickWidth = brickArr[0][0].hbox.getXsize();
    double brickHeight = brickArr[0][0].hbox.getYsize();
    int i, j;
    for (i = 0; i < 5; i++) {
        for (j = 0; j < 10; j++) {
            brickArr[i][j].hbox.setX(-1 + (j*(brickWidth+0.05)) + 0.025);
            brickArr[i][j].hbox.setY(1 - (i*(brickHeight+0.025))- 0.04);
        }
    }
    
    double brickRegion = brickArr[4][0].hbox.getY() - brickHeight;
    cout << brickRegion << endl;
    
    // creating game boundaries
    Hitbox leftborder(-1, 1, 0.02, 2);
    Hitbox rightborder(1-0.02, 1, 0.02, 2);
    Hitbox topborder(-1, 1, 2, 0.02);
    Hitbox bottomborder(-1, -1+0.02, 2, 0.02);
    
    while(!glfwWindowShouldClose(window)) {
        
        //  1. UPDATE POSITIONS
        
        // paddle and ball movement
        scaledGetCursorPos(window, cx, cy);
        player.updatePos(cx);
        ball.updatePos();
        
        //  2. DRAW COMPONENTS
        glClear(GL_COLOR_BUFFER_BIT);
        
        leftborder.draw();
        rightborder.draw();
        topborder.draw();
        bottomborder.draw();
        
        player.draw();
        ball.draw();
        
//        for (i = 0; i < 5; i++) {
//            for (j = 0; j < 10; j++) {
//                if (brickArr[i][j].getState()){
//                    brickArr[i][j].draw();
//                }
//            }
//        }
//
        
        //  3. COLLISION DETECTION
        
        // brick collision detection
        if (ball.hbox.getY() > brickRegion) {
            for (i = 0; i < 5; i++) {
                for (j = 0; j < 10; j++) {
                    if (ball.collison_dectection(brickArr[i][j].hbox)) {
                        brickArr[i][j].changeState();
                        ball.changeXmult();
                        ball.changeXmult();
                        ball.setAngle(ball.getAngle()+(rand() % 10));
                    }
                    
                    if (brickArr[i][j].getState()){
                        brickArr[i][j].draw();
                    }
                }
            }
        }
        
        ball.draw();
        
        
        // left and right boundary collision detection
        if (((ball.hbox.getX()+ball.hbox.getXsize()) > (1-0.05)) || (ball.hbox.getX() < (-1+0.025))) {
            cout << "change direction" << endl;
            ball.changeXmult();
        }
        
        // top boundary collision detection
        if (ball.hbox.getY() > (1-0.05)) {
            cout << "change direction" << endl;
            ball.changeYmult();
        }
        
        
        if (ball.collison_dectection(player.hbox)) {
            cout << "hit paddle" << endl;
            ball.changeYmult();
            ball.setAngle(ball.getAngle()+(rand() % 10));
        }
        
        if (ball.hbox.getY() < -1) {
            ball.setVelocity(0);
        
            
            glfwTerminate();
            
            return 1;
        }
        
        /* Swap front and back buffers */
        glfwSwapBuffers(window);

        /* Poll for and process events */
        glfwPollEvents();
    }
}
