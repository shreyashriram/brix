//
//  Brick.cpp
//  Brix
//
//  Created by Shreya Shriram on 12/7/21.
//
#include <iostream>
using namespace std;

#include <stdio.h>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include "Hitbox.h"
#include "Brick.h"


Brick::Brick() : hbox(-1, 1, 0.15, 0.05), r (0.0f), g(1.0f), b(0.125f), state(true) {};
Brick::Brick(double xpos, double ypos) : hbox(xpos, ypos, 0.4, 0.05), r(0.0f), g(1.0f), b(0.125f), state(true){};

void Brick::draw() {
    glColor3f(0.0, 0.0, 1.0);
    glBegin(GL_QUADS);
    glVertex2f(hbox.getX(), hbox.cornerY);
    glVertex2f(hbox.cornerX + hbox.sizeX, hbox.cornerY);
    glVertex2f(hbox.cornerX + hbox.sizeX, hbox.cornerY - hbox.sizeY);
    glVertex2f(hbox.cornerX, hbox.cornerY - hbox.sizeY);

    glEnd();
}

bool Brick::getState() {
    return state;
}

void Brick::changeState() {
    state = false;
}

