//
//  Paddle.cpp
//  Brix
//
//  Created by Shreya Shriram on 12/7/21.
//
#include <iostream>
using namespace std;

#include <stdio.h>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include "Hitbox.h"
#include "Paddle.h"


Paddle::Paddle() : hbox(0, -0.85, 0.2, 0.05) {};
Paddle::Paddle(double xpos, double ypos, double width, double height) : hbox(0, ypos, width, height) {};

void Paddle::updatePos(double x) {
    
    // adjusting x so that "center mouse position" is accounted for
    x = x - (hbox.getXsize()/2);
    hbox.setX(x);
}

void Paddle::draw()
{
    //scaledGetCursorPos(cx, cy);
    glColor3f(0.0f, 1.0f, 0.125f);
    glBegin(GL_QUADS);
    glVertex2f(hbox.cornerX, hbox.cornerY);
    glVertex2f(hbox.cornerX + hbox.sizeX, hbox.cornerY);
    glVertex2f(hbox.cornerX + hbox.sizeX, hbox.cornerY - hbox.sizeY);
    glVertex2f(hbox.cornerX, hbox.cornerY - hbox.sizeY);
    glEnd();
}



